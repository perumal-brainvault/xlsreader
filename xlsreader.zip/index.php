<?php

require_once 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$filename = 'products.xlsx';
$spreadsheet = IOFactory::load($filename);

$worksheet = $spreadsheet->getActiveSheet();
$rows = $worksheet->toArray();

$productListing = '<html><table border="1">';
for($i=1;$i<count($rows);$i++) {
    $productListing .= '<tr>';
    for($j=0;$j<count($rows[$i]);$j++) {
        $productListing .= '<td>' . $rows[$i][$j] . '</td>';
    }
    $productListing .= '</tr>';
}
$productListing .= '</table></html>';

echo $productListing;
